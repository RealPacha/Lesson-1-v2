"use strict"

const products = [
	{title : 'Notebook', price : 2000},
	{title : 'Mouse', price : 5},
	{title : 'Keyboard', price : 8},
	{title : 'Display', price : 400}
];

const renderProduct = (title, price) => 
	`<div class="card border-dark my-3 mx-3" style="max-width: 18rem;">
						<img src="img/no_image.png" class="card-img-top img-fluid" alt="..." style="width: 700px; height: 230px;">
						<div class="card-body text-dark">
							<h5 class="card-title text-center">${title}</h5>
							<div class="row">
								<div class="col-6 text-left">
									${price} $
								</div>
								<div class="col-6 text-right">
									<button type="button" class="btn btn-outline-dark">Купить</button>
								</div>
							</div>
						</div>
					</div>`;

renderProduct ('Клавиатура', '100$'); // Значение по умолчанию. Выводит в название "Клавиатура", а в "цену" 100$


const renderPage = list => {
	const productList = list.map ( item => renderProduct (item.title, item.price) );
	var space = productList.join(''); // .join ('') добавляет пустую строку после каждого элемента из объекта "products"
	document.querySelector('.products').innerHTML = space;

};

renderPage (products);

// Немного сократил функцию renderProduct, убрав "return" и убрав "{}"